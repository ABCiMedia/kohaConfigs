Download Stable Version 2 from Release Panel.

Find Readme.pdf For more information.

SUGGESTIONS ARE WELCOME. FEEL FREE TO CONTACT.

Introduction:

In out management system is web based application. It is used to track the patrons who visits to library or related locations like study zone, reading room etc. It’ll scan the barcode from the ID and log the entry time and exit time of the patrons. The patron data will be fetched from the KOHA database along with the images and displayed on this system.

There are two interfaces, one is for the reading barcodes at the door and another one is for access the reports. This system will generate four types of reports in the form of excel sheet and can be downloaded. There are three user by default for administration of this system. Master user can have eye on every location added in the system. And the other two users for respected locations.

The system uses koha database to fetch the information of patrons and store it another database along with the location, entry time and exit time. These data can be accessed from admin panel in various manner like datewise, timewise, USN wise and many more.

Thank You

Locate/Find Readme.pdf For more information.

Profile @ https://omkar2403.github.io/its_me/

Mail Me @ omkar.kakeru@gmail.com

Demo Video @ https://www.youtube.com/watch?v=1LqqwKYamHc&t=12s

In Out Management System by Omkar Kakeru is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.

